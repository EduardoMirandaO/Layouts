import 'package:flutter/material.dart';

void main() {
  // debugPaintSizeEnabled = true;
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Widget titleSection = Container(
      padding: const EdgeInsets.all(32),
      child: Row(
        children: [
          Expanded(
            /*1*/
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                /*2*/
                Container(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: const Text(
                    'Rei II',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Text(
                  'Evangelion: 1.0 You Are (Not) Alone',
                  style: TextStyle(
                    color: Colors.grey[500],
                  ),
                ),
              ],
            ),
          ),
          /*3*/
          Icon(
            Icons.star,
            color: Colors.red[500],
          ),
          const Text('99'),
        ],
      ),
    );

    Color color = Theme.of(context).primaryColor;

    Widget buttonSection = Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        _buildButtonColumn(color, Icons.favorite, 'Preferidos'),
        _buildButtonColumn(color, Icons.add_a_photo, 'Agregar'),
        _buildButtonColumn(color, Icons.share, 'Compartir'),
      ],
    );

    Widget textSection = const Padding(
      padding: EdgeInsets.all(32),
      child: Text(
        'La Rei que aparece en The End of Evangelion es la tercera. La primera fue asesinada por Naoko Akagi en el año 2010,'
        'y la segunda murió en su combate contra el ángel Armisael, sacrificando al EVA-00 para derrotarlo.                                                     '
        'Al inicio de la serie, Rei Ayanami es presentada como una joven enigmática de carácter introvertido, '
        'silenciosa y nada comunicativa, que a pesar de confiar en las personas adultas, sólo'
        'manifiesta emociones y lealtad sincera hacia Gendo Ikari, con quien también mantiene una relación distante.'
        '',
        softWrap: true,
      ),
    );

    return MaterialApp(
      title: 'Actividad 2',
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Eduardo Israel Miranda Ortega'),
        ),
        body: ListView(
          children: [
            Image.asset(
              'images/background.gif',
              fit: BoxFit.cover,
            ),
            titleSection,
            buttonSection,
            textSection,
          ],
        ),
      ),
    );
  }

  Column _buildButtonColumn(Color color, IconData icon, String label) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(icon, color: color),
        Container(
          margin: const EdgeInsets.only(top: 8),
          child: Text(
            label,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w400,
              color: color,
            ),
          ),
        ),
      ],
    );
  }
}
