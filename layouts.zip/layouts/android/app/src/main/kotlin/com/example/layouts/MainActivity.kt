package com.example.layouts

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
